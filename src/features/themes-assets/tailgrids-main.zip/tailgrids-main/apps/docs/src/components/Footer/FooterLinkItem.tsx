import Link from "next/link";
import { FooterLinkItemType } from "./footerData";

type FooterLinkItemProps = {
  link: FooterLinkItemType;
};

export default function FooterLinkItem({ link }: FooterLinkItemProps) {
  return (
    <Link
      href={link.url}
      target={link.external ? "_blank" : "_self"}
      rel={link.external ? "noopener noreferrer" : undefined}
      className="inline-flex cursor-pointer text-base text-tg-text-color dark:text-gray-400 duration-200 hover:text-primary-500"
    >
      {link.title}
    </Link>
  );
}
